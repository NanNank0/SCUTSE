﻿#include "Game.h"
#include <SFML/Graphics.hpp>
#include <TGUI/TGUI.hpp>
#include <TGUI/Backend/SFML-Graphics.hpp>
#include <queue>
#include <limits>
#include <vector>
#include <memory>
#include "Pathfinding.h"
#include "Guard.h"

void Game::showCheatWindow() {
    // ??????????????????
    int winW = 720, winH = 580;
    sf::RenderWindow cw(sf::VideoMode(sf::Vector2u(winW, winH)), "Cheat - Optimal Guard Placement");
    tgui::Gui gui(cw);
    try { tgui::Font ft("resources/wryh.ttf"); gui.setFont(ft); } catch (...) {}

    // ????
    auto goldInput = tgui::EditBox::create();
    goldInput->setPosition(20, 15); goldInput->setSize(100, 30);
    goldInput->setDefaultText("Gold"); goldInput->setText("30");
    goldInput->setTextSize(16);
    gui.add(goldInput);

    // ????
    std::vector<CheatSuggestion> result;
    int totalDmg = 0, goldUsed = 0, totalGuards = 0;
    bool calculated = false;

    auto calcBtn = tgui::Button::create();
    calcBtn->setPosition(140, 15); calcBtn->setSize(100, 30);
    calcBtn->setText("Calculate"); calcBtn->setTextSize(15);
    calcBtn->getRenderer()->setBackgroundColor(tgui::Color(180, 220, 180));
    calcBtn->onPress([&] {
int budget = std::max(1, tgui::String(goldInput->getText()).toInt());
        result.clear(); totalDmg = 0; goldUsed = 0; totalGuards = 0;

        // ????????????????????????
        auto emptyGrid = std::vector<std::vector<std::unique_ptr<Guard>>>(m_n);
        for (auto& row : emptyGrid) row.resize(m_n);
        auto path = ::findOptimalPath(m_n, m_spawn, m_defense, emptyGrid);
        if (path.empty()) { calculated = true; return; }

        // ????????????????
        auto onPath = std::vector<std::vector<bool>>(m_n, std::vector<bool>(m_n, false));
        for (auto& p : path) onPath[p.x][p.y] = true;

        // ???????
        auto occ = std::vector<std::vector<bool>>(m_n, std::vector<bool>(m_n, false));
        occ[m_spawn.x][m_spawn.y] = true;
        occ[m_defense.x][m_defense.y] = true;

        // ?????????????????????????
        int wastedGold = 0, wastedCount = 0;
        int costs[6] = {0,3,3,4,5,1};
        for (int r = 0; r < m_n; ++r) {
            for (int c = 0; c < m_n; ++c) {
                if (m_guards[r][c]) {
                    occ[r][c] = true;
                    Guard* g = m_guards[r][c].get();
                    if (onPath[r][c]) {
                        // ????????????
                        wastedGold += costs[g->getCost()];
                        wastedCount++;
                        result.push_back({r, c, -1, g->getDirection()});
                    } else {
                        // ???????????
                        int d = 0;
                        for (auto& p : path)
                            if (g->inRange({r,c}, p)) d += g->getAttack();
                        totalGuards++; totalDmg += d;
                        result.push_back({r, c, -2, g->getDirection()});
                    }
                }
            }
        }

        // ?????????????????
        while (goldUsed < budget) {
            int bestR = -1, bestC = -1, bestType = -1;
            Direction bestDir = Direction::Up;
            int bestDmg = -1;

            for (int r = 0; r < m_n && bestDmg != 0; ++r) {
                for (int c = 0; c < m_n && bestDmg != 0; ++c) {
                    if (occ[r][c] || onPath[r][c]) continue;
                    for (int t = 1; t <= 5; ++t) {
                        int cst = costs[t];
                        if (goldUsed + cst > budget) continue;
                        Direction dirs[4] = {Direction::Up, Direction::Down, Direction::Left, Direction::Right};
                        for (int di = 0; di < 4; ++di) {
                            Direction dir = dirs[di];
                            auto guard = [&]() -> std::unique_ptr<Guard> {
                                switch (t) { case 1: return std::make_unique<TankGuard>(dir);
                                    case 2: return std::make_unique<SwordmanGuard>(dir);
                                    case 3: return std::make_unique<ArcherGuard>(dir);
                                    case 4: return std::make_unique<MageGuard>(dir);
                                    case 5: return std::make_unique<PlaceholderGuard>(dir);
                                    default: return nullptr; }
                            }();
                            if (!guard) continue;
                            int dmg = 0;
                            for (auto& p : path)
                                if (guard->inRange({r,c}, p)) dmg += guard->getAttack();
                            if (dmg > bestDmg) {
                                bestDmg = dmg; bestR = r; bestC = c;
                                bestType = t; bestDir = dir;
                            }
                        }
                    }
                }
            }
            if (bestR < 0 || bestDmg <= 0) break;
            occ[bestR][bestC] = true;
            goldUsed += costs[bestType];
            totalDmg += bestDmg; totalGuards++;
            result.push_back({bestR, bestC, bestType, bestDir});
        }
        calculated = true;
    });
    gui.add(calcBtn);

    auto closeBtn = tgui::Button::create();
    closeBtn->setPosition(260, 15); closeBtn->setSize(80, 30);
    closeBtn->setText("Close"); closeBtn->setTextSize(15);
    closeBtn->onPress([&]{ cw.close(); });
    gui.add(closeBtn);

    int gridX = 30, gridY = 70, cSize = std::min(50, (winW - 300) / m_n);
    if (cSize > 45) cSize = 45;

    while (cw.isOpen()) {
        while (const auto oe = cw.pollEvent()) {
            if (oe->is<sf::Event::Closed>()) cw.close();
            gui.handleEvent(*oe);
        }
        cw.clear(sf::Color(40, 40, 45));

        // ????
        sf::RectangleShape cell(sf::Vector2f(cSize, cSize));
        cell.setOutlineThickness(1); cell.setOutlineColor(sf::Color(100,100,100));

        for (int r = 0; r < m_n; ++r) {
            for (int c = 0; c < m_n; ++c) {
                cell.setFillColor(sf::Color::Transparent);
                cell.setPosition(sf::Vector2f(gridX + c * cSize, gridY + r * cSize));
                cw.draw(cell);
            }
        }

        // ???????????????????
        sf::Color typeColors[6] = {sf::Color::Transparent, sf::Color(100,200,255),
            sf::Color(255,100,100), sf::Color(100,255,100), sf::Color(200,100,255), sf::Color(255,255,100)};
        char typeChars[6] = {' ', 'K', 'S', 'A', 'M', 'P'};

        for (auto& s : result) {
            sf::RectangleShape gr(sf::Vector2f(cSize, cSize));
            gr.setFillColor(typeColors[s.type]);
            gr.setOutlineThickness(2); gr.setOutlineColor(sf::Color::White);
            gr.setPosition(sf::Vector2f(gridX + s.col * cSize, gridY + s.row * cSize));
            cw.draw(gr);

            sf::Text gt(m_font, std::string(1, typeChars[s.type]), cSize * 0.6f);
            gt.setFillColor(sf::Color::Black);
            auto gb = gt.getLocalBounds();
            gt.setOrigin(sf::Vector2f(gb.size.x/2, gb.size.y/2));
            gt.setPosition(sf::Vector2f(gridX + s.col * cSize + cSize/2, gridY + s.row * cSize + cSize/2));
            cw.draw(gt);
        }

        // ????/???
        sf::RectangleShape sr(sf::Vector2f(cSize, cSize));
        sr.setOutlineThickness(2); sr.setOutlineColor(sf::Color::White);
        sr.setFillColor(sf::Color::Red);
        sr.setPosition(sf::Vector2f(gridX + m_spawn.y * cSize, gridY + m_spawn.x * cSize));
        cw.draw(sr);
        sr.setFillColor(sf::Color::Blue);
        sr.setPosition(sf::Vector2f(gridX + m_defense.y * cSize, gridY + m_defense.x * cSize));
        cw.draw(sr);

        // ??????
        int infoX = gridX + m_n * cSize + 30;
        int iy = 70;
        sf::Text ttl(m_font, "=== Results ===", 16);
        ttl.setFillColor(sf::Color(200,255,200));
        ttl.setPosition(sf::Vector2f(infoX, iy)); cw.draw(ttl); iy += 28;

        auto drawInfo = [&](const std::string& lb, const std::string& vl, const sf::Color& vc) {
            sf::Text lt(m_font, lb, 14); lt.setFillColor(sf::Color(180,180,180));
            lt.setPosition(sf::Vector2f(infoX, iy)); cw.draw(lt);
            sf::Text vt(m_font, vl, 14); vt.setFillColor(vc);
            vt.setPosition(sf::Vector2f(infoX + 100, iy)); cw.draw(vt);
            iy += 22;
        };

        drawInfo("Map:", std::to_string(m_n)+"x"+std::to_string(m_n), sf::Color::White);
        drawInfo("Budget:", std::to_string(goldUsed)+"/"+tgui::String(goldInput->getText()).toStdString(), sf::Color::Yellow);
        drawInfo("Guards:", std::to_string(totalGuards), sf::Color::White);
        if (calculated) drawInfo("Total Dmg:", std::to_string(totalDmg), sf::Color(255,200,100));

        if (calculated && totalGuards > 0) {
            iy += 10;
            sf::Text lg(m_font, "--- Legend ---", 14);
            lg.setFillColor(sf::Color(150,200,255));
            lg.setPosition(sf::Vector2f(infoX, iy)); cw.draw(lg); iy += 22;

            const char* typeNames[6] = {"", "Tank(K)", "Sword(S)", "Archer(A)", "Mage(M)", "Place(P)"};
            for (int t = 1; t <= 5; ++t) {
                int cnt = 0;
                for (auto& s : result) if (s.type == t) cnt++;
                if (cnt > 0) {
                    sf::Text lt(m_font, std::string(typeNames[t]) + " x" + std::to_string(cnt), 13);
                    lt.setFillColor(typeColors[t]);
                    lt.setPosition(sf::Vector2f(infoX + 10, iy)); cw.draw(lt); iy += 18;
                }
            }
        }

        gui.draw(); cw.display();
    }
}
